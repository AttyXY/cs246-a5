#include "player.h"
using namespace std;

Player::Player(Colour c, double score): c{c}, score{score} {}
Player::~Player() {}
